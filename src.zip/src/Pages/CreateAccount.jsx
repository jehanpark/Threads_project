// import React from "react";
// // import CreateAccountItemDk from "../Components/Login/CreateAccountItem_dk";
// import CreateAccount_de from "../Components/Login/CreateAccount_de"; // 다은 만든 회원가입 화면

// const CreateAccount = () => {
//   return (
//     <div>
//       <CreateAccountItemDk />
//     </div>
//   );
// };

// export default CreateAccount;
