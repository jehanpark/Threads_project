import React from "react";

const MyProfileImgs = () => {
  return <div>MyProfileImgs</div>;
};

export default MyProfileImgs;
