import React from "react";

const ThreadDetail = () => {
  return <div>ThreadDetail</div>;
};

export default ThreadDetail;
