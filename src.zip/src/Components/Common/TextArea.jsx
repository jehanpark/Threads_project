import React from "react";

const TextArea = (submit, type, placebolder) => {
  return <div></div>;
};

export default TextArea;
