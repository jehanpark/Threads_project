import React from "react";
import styled from "styled-components";

const Wrapper = styled.div``;

const Posted = styled.div``;

const CommentWrite = styled.div``;

const Comment = () => {
  return (
    <Wrapper>
      <Posted>Comment</Posted>
      <CommentWrite></CommentWrite>
    </Wrapper>
  );
};

export default Comment;
