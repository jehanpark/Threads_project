import React from "react";

const Input = (onSubmit, type, placeholder) => {
  return <div></div>;
};

export default Input;
