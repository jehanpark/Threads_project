import React from 'react'

const Mobile_Modal = () => {
  return (
    <div>
      
    </div>
  )
}

export default Mobile_Modal

