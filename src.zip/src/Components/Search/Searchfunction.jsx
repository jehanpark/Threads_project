import React from "react";
import Searchbar from "./Searchbar";
import Searchhistory from "./Searchhistory";
import styled from "styled-components";
import GlobalStyles, {
  lightTheme,
  darkTheme,
} from "../../styles/GlobalStyles.styles";

const Searchfunction = () => {
  return <div></div>;
};

export default Searchfunction;
