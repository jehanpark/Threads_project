import React from "react";

const Thread = () => {
  return <div>Thread</div>;
};

export default Thread;
