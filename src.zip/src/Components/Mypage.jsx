import React from "react";

const Mypage = () => {
  return <div>Mypage</div>;
};

export default Mypage;
