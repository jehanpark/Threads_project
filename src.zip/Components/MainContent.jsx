import React from "react";

const MainContent = () => {
  return <div>MainContent</div>;
};

export default MainContent;
