import React from "react";

const PostNew = () => {
  return <div>PostNew</div>;
};

export default PostNew;
