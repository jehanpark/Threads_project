import React from 'react'

const BorderWrapper = () => {
  return (
    <div>
      
    </div>
  )
}

export default BorderWrapper
