import React from "react";

const Sidebar = () => {
  return <div></div>;
};

export default Sidebar;
