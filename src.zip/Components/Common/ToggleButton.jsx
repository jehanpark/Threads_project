import React from "react";

const ToggleButton = (bool) => {
  return <div></div>;
};

export default ToggleButton;
