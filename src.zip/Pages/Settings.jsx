import React from "react";
import SettingsItem_de from "../Components/SettingsItem_de";

const Settings = () => {
  return (
    <div>
      <SettingsItem_de />
    </div>
  );
};

export default Settings;
