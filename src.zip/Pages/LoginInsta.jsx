import React from "react";
import LoginItemInstaDk from "../Components/Login/LoginItemInsta_dk";

const LoginInsta = () => {
  return (
    <>
      <LoginItemInstaDk />
    </>
  );
};

export default LoginInsta;
