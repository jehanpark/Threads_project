import React from "react";

const Follow = () => {
  return <div>Follow</div>;
};

export default Follow;
